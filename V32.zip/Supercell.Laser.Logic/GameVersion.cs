﻿namespace Supercell.Laser.Logic
{
    public class GameVersion
    {
        public const int MAJOR = 29;
        public const int BUILD = 258;
    }
}